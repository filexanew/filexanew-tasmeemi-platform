import JSZip from 'jszip';
import AppCode from '../../App.tsx?raw';
import IndexCssCode from '../../index.css?raw';
import IndexHtmlCode from '../../index.html?raw';
import IndexTsxCode from '../../index.tsx?raw';
import PackageJsonCode from '../../package.json?raw';
import SupabaseClientCode from '../../supabaseClient.js?raw';
import TsconfigJsonCode from '../../tsconfig.json?raw';
import TypesCode from '../../types.ts?raw';
import ViteConfigCode from '../../vite.config.ts?raw';
import GitignoreCode from '../../.gitignore?raw';
import RedirectsCode from '../../public/_redirects?raw';

import LayoutCode from '../../components/Layout.tsx?raw';
import BuyerGalleryCode from '../../components/BuyerGallery.tsx?raw';
import SellerDashboardCode from '../../components/SellerDashboard.tsx?raw';
import LoginPageCode from '../../components/LoginPage.tsx?raw';

import I18nCode from '../i18n.ts?raw';
import SupabaseRetryCode from './supabaseRetry.ts?raw';

export const exportProjectAsZip = async (onProgress?: (progress: number) => void): Promise<Blob> => {
  const zip = new JSZip();

  // 1. Root Files
  zip.file('App.tsx', AppCode);
  zip.file('index.css', IndexCssCode);
  zip.file('index.html', IndexHtmlCode);
  zip.file('index.tsx', IndexTsxCode);
  zip.file('package.json', PackageJsonCode);
  zip.file('supabaseClient.js', SupabaseClientCode);
  zip.file('tsconfig.json', TsconfigJsonCode);
  zip.file('types.ts', TypesCode);
  zip.file('vite.config.ts', ViteConfigCode);
  zip.file('.gitignore', GitignoreCode);

  if (onProgress) onProgress(30);

  // 2. Public Folder
  const publicFolder = zip.folder('public');
  if (publicFolder) {
    publicFolder.file('_redirects', RedirectsCode);
  }

  if (onProgress) onProgress(50);

  // 3. Components Folder
  const componentsFolder = zip.folder('components');
  if (componentsFolder) {
    componentsFolder.file('Layout.tsx', LayoutCode);
    componentsFolder.file('BuyerGallery.tsx', BuyerGalleryCode);
    componentsFolder.file('SellerDashboard.tsx', SellerDashboardCode);
    componentsFolder.file('LoginPage.tsx', LoginPageCode);
  }

  if (onProgress) onProgress(80);

  // 4. Src Folder & Utilities
  const srcFolder = zip.folder('src');
  if (srcFolder) {
    srcFolder.file('i18n.ts', I18nCode);
    const utilsFolder = srcFolder.folder('utils');
    if (utilsFolder) {
      utilsFolder.file('supabaseRetry.ts', SupabaseRetryCode);
    }
  }

  if (onProgress) onProgress(90);

  // Generate the ZIP
  const content = await zip.generateAsync({ type: 'blob' });
  
  if (onProgress) onProgress(100);
  return content;
};

export const triggerDownload = (blob: Blob, filename = 'tasmeemi-digital-marketplace.zip') => {
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  
  // Cleanup
  setTimeout(() => {
    document.body.removeChild(anchor);
    window.URL.revokeObjectURL(url);
  }, 100);
};
