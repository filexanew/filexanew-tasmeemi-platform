
export async function withRetry<T>(
  fn: () => Promise<{ data: T | null; error: any }>,
  retryCount = 0,
  maxRetries = 3,
  delay = 2000
): Promise<{ data: T | null; error: any }> {
  try {
    const result = await fn();
    const isLockError = result.error?.message?.includes('Lock broken') || result.error?.message?.includes('stole it');
    const isNetworkError = result.error?.message === 'Failed to fetch' || !window.navigator.onLine;
    const isDbRestartError = result.error?.message?.includes('terminating connection') || result.error?.message?.includes('57P01');
    
    if ((isNetworkError || isLockError || isDbRestartError) && retryCount < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retryCount + 1, maxRetries, delay);
    }
    return result;
  } catch (err: any) {
    const isLockError = err.message?.includes('Lock broken') || err.message?.includes('stole it');
    const isNetworkError = err.message === 'Failed to fetch' || !window.navigator.onLine;
    const isDbRestartError = err.message?.includes('terminating connection') || err.message?.includes('57P01');

    if ((isNetworkError || isLockError || isDbRestartError) && retryCount < maxRetries) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return withRetry(fn, retryCount + 1, maxRetries, delay);
    }
    return { data: null, error: err };
  }
}
