
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '../App.tsx';
import { withRetry } from '../src/utils/supabaseRetry.ts';

export const LoginPage: React.FC = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await withRetry(async () => await supabase.auth.signInWithPassword({
      email,
      password,
    }));

    if (error) {
      let msg = error.message;
      if (msg === 'Invalid login credentials') msg = t('invalid_credentials');
      else if (msg === 'Failed to fetch') msg = t('network_error');
      setError(msg);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 w-full max-w-md animate-in fade-in zoom-in duration-500">
        <div className="text-center mb-8">
           <div className="text-5xl mb-4">🔐</div>
           <h1 className="text-2xl font-black text-gray-900">{t('login_title')}</h1>
           <p className="text-gray-400 text-sm mt-2">{t('login_subtitle')}</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-xs font-bold border border-red-100">
               ⚠️ {error}
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-xs font-black text-gray-500 px-2 uppercase">{t('email')}</label>
            <input 
              required
              type="email" 
              value={email} 
              onChange={e => setEmail(e.target.value)}
              className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 focus:bg-white transition-all font-bold outline-none"
              placeholder="example@mail.com"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black text-gray-500 px-2 uppercase">{t('password')}</label>
            <input 
              required
              type="password" 
              value={password} 
              onChange={e => setPassword(e.target.value)}
              className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl focus:border-indigo-500 focus:bg-white transition-all font-bold outline-none"
              placeholder="••••••••"
            />
          </div>

          <button 
            disabled={loading}
            type="submit" 
            className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition active:scale-95 disabled:bg-gray-300"
          >
            {loading ? t('verifying') : t('login_button') + ' 🚀'}
          </button>
        </form>
      </div>
    </div>
  );
};
