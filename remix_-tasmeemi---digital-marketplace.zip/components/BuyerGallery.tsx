
import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Product, Order, SellerSettings, SpecialRequest } from '../types.ts';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '../App.tsx';
import { withRetry } from '../src/utils/supabaseRetry.ts';

interface BuyerGalleryProps {
  products: Product[];
  sellerSettings: SellerSettings;
  onPurchase: (order: Partial<Order>) => Promise<boolean>;
  onSpecialRequest: (req: Partial<SpecialRequest>) => Promise<boolean>;
}

export const BuyerGallery: React.FC<BuyerGalleryProps> = ({ products, sellerSettings, onPurchase, onSpecialRequest }) => {
  const { t } = useTranslation();
  const [view, setView] = useState<'gallery' | 'tracking' | 'special'>('gallery');
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [trackingPhone, setTrackingPhone] = useState('');
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [mySpecials, setMySpecials] = useState<SpecialRequest[]>([]);
  
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  
  const [specName, setSpecName] = useState('');
  const [specPhone, setSpecPhone] = useState('');
  const [specDesc, setSpecDesc] = useState('');
  const [specSuccess, setSpecSuccess] = useState(false);
  const [specReceiptImage, setSpecReceiptImage] = useState<string | null>(null);
  
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const specReceiptInputRef = useRef<HTMLInputElement>(null);

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    if (trackingPhone) {
      fetchMyData();
    }
  }, [trackingPhone, success, specSuccess]);

  useEffect(() => {
    setActiveImageIndex(0);
  }, [detailProduct]);

  const fetchMyData = async () => {
    try {
      const { data: ords, error: ordError } = await withRetry(async () => 
        await supabase.from('orders').select('*').eq('buyer_phone', trackingPhone).order('timestamp', { ascending: false })
      );
      if (ordError) throw ordError;
      if (ords) setMyOrders(ords);

      const { data: specs, error: specError } = await withRetry(async () => 
        await supabase.from('special_requests').select('*').eq('buyer_phone', trackingPhone).order('timestamp', { ascending: false })
      );
      if (specError) throw specError;
      if (specs) setMySpecials(specs);
    } catch (err: any) {
      console.error(`Error fetching user data:`, err);
    }
  };

  const getOrderDownloadUrl = (order: Order) => {
    const product = products.find(p => p.id === order.product_id);
    const url = order.sale_file_url || product?.sale_file_url;
    return (url && url.trim() !== "") ? url : null;
  };

  // ميزة التحميل التلقائي بعد 24 ساعة
  const isEligibleForDownload = (order: Order) => {
    if (order.status === 'approved') return true;
    if (order.status === 'pending') {
      const oneDayInMs = 24 * 60 * 60 * 1000;
      return (Date.now() - order.timestamp) > oneDayInMs;
    }
    return false;
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsSubmitting(true);
      const fileName = `receipt_${Date.now()}_${file.name.replace(/\s+/g, '_')}`;
      
      const uploadFn = async () => {
        const uploadUrl = `${SUPABASE_URL}/storage/v1/object/receipts/${fileName}`;
        const response = await fetch(uploadUrl, {
          method: 'POST',
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': file.type || 'image/jpeg'
          },
          body: file
        }).catch(err => {
          throw new Error("Failed to fetch");
        });

        if (!response.ok) {
          const responseData = await response.json();
          return { data: null, error: new Error(responseData.message || t('receipt_upload_failed')) };
        }
        
        const { data: { publicUrl } } = supabase.storage.from('receipts').getPublicUrl(fileName);
        return { data: publicUrl, error: null };
      };

      try {
        const { data: publicUrl, error: uploadError } = await withRetry(uploadFn);
        
        if (uploadError) throw uploadError;
        if (publicUrl) setReceiptImage(publicUrl);
      } catch (err: any) {
        console.error(`Upload error:`, err);
        const msg = err.message === 'Failed to fetch' 
          ? t('connection_failed')
          : err.message;
        alert(`❌ ${t('upload_error')}: ${msg}`);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct || !receiptImage) return;
    setIsSubmitting(true);
    const newOrder: Partial<Order> = {
      id: Math.random().toString(36).substring(2, 9).toUpperCase(),
      product_id: selectedProduct.id,
      product_name: selectedProduct.name,
      price: selectedProduct.price,
      buyer_name: buyerName,
      buyer_phone: buyerPhone,
      receipt_image: receiptImage,
      status: 'pending',
      sale_file_url: selectedProduct.sale_file_url
    };
    const successResult = await onPurchase(newOrder);
    setIsSubmitting(false);
    if (successResult) {
      setSuccess(true);
      setTrackingPhone(buyerPhone);
      setTimeout(() => { setShowCheckout(false); setSuccess(false); setView('tracking'); }, 2000);
    }
  };

  const handleSpecReceiptChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsSubmitting(true);
    const fileName = `${Math.random().toString(36).substring(2, 9)}_${file.name}`;
    
    const uploadFn = async () => {
      const { error } = await supabase.storage.from('receipts').upload(fileName, file);
      if (error) return { data: null, error };
      const { data: { publicUrl } } = supabase.storage.from('receipts').getPublicUrl(fileName);
      return { data: publicUrl, error: null };
    };

    try {
      const { data: publicUrl, error: uploadError } = await withRetry(uploadFn);
      if (uploadError) throw uploadError;
      if (publicUrl) setSpecReceiptImage(publicUrl);
    } catch (err: any) {
      console.error(`Upload error:`, err);
      alert(`❌ خطأ في الرفع: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSpecialRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!specReceiptImage) {
      alert(t('upload_receipt_first'));
      return;
    }
    setIsSubmitting(true);
    const newReq: Partial<SpecialRequest> = {
      id: Math.random().toString(36).substring(2, 9).toUpperCase(),
      buyer_name: specName,
      buyer_phone: specPhone,
      specifications: specDesc,
      receipt_image: specReceiptImage,
      status: 'pending_payment'
    };
    const successResult = await onSpecialRequest(newReq);
    setIsSubmitting(false);
    if (successResult) {
      setSpecSuccess(true);
      setSpecReceiptImage(null);
      setTimeout(() => { setSpecSuccess(false); setView('tracking'); setSpecName(''); setSpecPhone(''); setSpecDesc(''); }, 2000);
    }
  };

  const handleDownload = async (url: string | undefined, fileName: string, id: string) => {
    if (!url) {
      alert(`⚠️ ${t('file_link_unavailable')}`);
      return;
    }
    
    setDownloadingId(id);
    
    try {
      // التحقق مما إذا كان الرابط من Supabase Storage
      if (url.includes(SUPABASE_URL) && url.includes('/storage/v1/object/public/')) {
        const parts = url.split('/storage/v1/object/public/');
        if (parts.length > 1) {
          const pathParts = parts[1].split('/');
          const bucket = pathParts[0];
          const path = pathParts.slice(1).join('/');
          
          // استخدام SDK التحميل لضمان تجاوز مشاكل CORS والحصول على الملف كـ Blob
          const { data, error } = await withRetry(async () => await supabase.storage.from(bucket).download(path));
          
          if (error) throw error;
          
          if (data) {
            const blobUrl = window.URL.createObjectURL(data);
            const link = document.body.appendChild(document.createElement('a'));
            link.href = blobUrl;
            
            // محاولة استخراج الامتداد الصحيح
            const extension = path.split('.').pop() || '';
            const finalFileName = extension && !fileName.includes('.') ? `${fileName}.${extension}` : fileName;
            
            link.download = finalFileName;
            link.click();
            setTimeout(() => {
              link.remove();
              window.URL.revokeObjectURL(blobUrl);
            }, 100);
            return;
          }
        }
      }
      
      // إذا كان الرابط خارجياً، نفتحه في نافذة جديدة لتجنب مشاكل CORS (Failed to fetch)
      window.open(url, '_blank');
    } catch (error) {
      console.error("Download failed:", error);
      // الملاذ الأخير: فتح الرابط في نافذة جديدة
      window.open(url, '_blank');
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-center gap-3 mb-12">
        <div className="bg-white p-1.5 rounded-2xl flex border border-beige-200 shadow-sm text-gray-700">
          <button onClick={() => setView('gallery')} className={`px-6 py-3 rounded-xl text-sm font-black transition ${view === 'gallery' ? 'bg-pastel-orange text-white shadow-lg' : 'opacity-50 hover:opacity-100'}`}>🛍️ {t('store')}</button>
          <button onClick={() => setView('special')} className={`px-6 py-3 rounded-xl text-sm font-black transition ${view === 'special' ? 'bg-pastel-orange text-white shadow-lg' : 'opacity-50 hover:opacity-100'}`}>✍️ {t('request_custom_design')}</button>
          <button onClick={() => setView('tracking')} className={`px-6 py-3 rounded-xl text-sm font-black transition ${view === 'tracking' ? 'bg-pastel-orange text-white shadow-lg' : 'opacity-50 hover:opacity-100'}`}>📦 {t('my_purchases')}</button>
        </div>
      </div>

      {view === 'gallery' && (
        <>
          <header className="mb-12 md:mb-20 text-center">
            <h1 className="text-4xl md:text-7xl font-black text-gray-800 mb-4 md:text-6xl tracking-tighter">{t('creativity_unlimited')}</h1>
            <p className="text-gray-500 font-bold text-base md:text-xl max-w-2xl mx-auto leading-relaxed mb-8 md:mb-12 px-4">{t('store_subtitle')}</p>
            
            <div className="max-w-xl mx-auto relative group px-4">
              <input 
                type="text" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={t('search_hint')} 
                className="w-full px-6 md:px-10 py-4 md:py-6 bg-white border-2 border-beige-200 rounded-2xl md:rounded-[2.5rem] font-black text-gray-700 outline-none focus:border-pastel-orange transition-all shadow-sm group-hover:shadow-xl text-sm md:text-base"
              />
              <div className="absolute left-10 md:left-6 top-1/2 -translate-y-1/2 text-gray-300">
                <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
              </div>
            </div>
          </header>

          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 md:py-32 bg-beige-50 rounded-3xl md:rounded-[4rem] border-4 border-dashed border-beige-100 font-bold text-gray-400 italic text-xl md:text-2xl mx-4">
              {searchTerm ? t('no_works_yet') : t('empty_store')}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-10">
              {filteredProducts.map((product) => (
                <div key={product.id} onClick={() => setDetailProduct(product)} className="group relative bg-beige-50 rounded-3xl md:rounded-[2.5rem] shadow-sm border border-beige-200 overflow-hidden cursor-pointer transition-all duration-500 hover:shadow-[0_20px_40px_-10px_rgba(0,0,0,0.08)] hover:-translate-y-1">
                  <div className="aspect-[4/3] bg-beige-100 relative overflow-hidden">
                    <img src={product.thumbnail} className="w-full h-full object-cover group-hover:scale-105 transition duration-700 ease-out" />
                    <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl text-[9px] font-black text-pastel-orange shadow-lg border border-white/20">{product.category}</div>
                    {Date.now() - product.created_at < 3 * 24 * 60 * 60 * 1000 && (
                      <div className="absolute top-4 left-4 bg-pastel-orange text-white px-3 py-1.5 rounded-xl text-[9px] font-black shadow-lg">{t('new_tag')} ✨</div>
                    )}
                  </div>
                  <div className="p-6 md:p-8">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-lg md:text-xl font-black text-gray-800 truncate flex-grow pr-2">{product.name}</h3>
                      <div className="text-pastel-orange font-black text-base md:text-lg whitespace-nowrap">{product.price} د.ل</div>
                    </div>
                    <p className="text-gray-500 text-xs md:text-sm font-bold line-clamp-2 mb-4 md:mb-6 h-8 md:h-10 leading-relaxed">{product.description}</p>
                    <div className="flex gap-2 md:gap-3">
                      <button className="flex-grow bg-pastel-orange text-white py-3 md:py-4 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black transition-all hover:bg-pastel-orange/90 active:scale-95 shadow-md">{t('buy_now')}</button>
                      <div className="w-10 h-10 md:w-12 md:h-12 bg-beige-50 rounded-xl md:rounded-2xl flex items-center justify-center text-gray-400 group-hover:bg-pastel-orange/10 group-hover:text-pastel-orange transition-colors">
                        <svg className="w-4 h-4 md:w-5 md:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {view === 'special' && (
        <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-10 duration-700">
          <div className="bg-beige-50 rounded-[3.5rem] shadow-2xl p-12 md:p-16 border border-beige-200 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-pastel-orange/5 rounded-full -mr-16 -mt-16 opacity-50"></div>
            <div className="relative z-10">
              <h2 className="text-5xl font-black text-gray-800 mb-4 tracking-tighter">{t('request_custom_design')} ✍️</h2>
              <p className="text-gray-500 font-bold text-lg mb-12 leading-relaxed">{t('special_request_subtitle')}</p>
              
              {specSuccess ? (
                <div className="text-center py-20">
                  <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 text-4xl">✅</div>
                  <h3 className="text-3xl font-black text-gray-800 mb-2">{t('received_request')}</h3>
                  <p className="text-gray-500 font-bold">{t('received_request_hint')}</p>
                </div>
              ) : (
                <form onSubmit={handleSpecialRequestSubmit} className="space-y-8">
                  <div className="bg-white p-8 rounded-[2.5rem] border-2 border-beige-200 mb-8">
                    <h3 className="text-xl font-black text-gray-800 mb-4 flex items-center gap-2">
                      <span className="text-pastel-orange">💳</span> {t('payment_settings')}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('bank_name')}</p>
                        <p className="text-lg font-black text-gray-700">{sellerSettings.bank_name}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('account_number')}</p>
                        <p className="text-lg font-black text-gray-700 tracking-tighter">{sellerSettings.account_number}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('iban')}</p>
                        <p className="text-lg font-black text-gray-700 tracking-tighter">{sellerSettings.iban}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('account_holder')}</p>
                        <p className="text-lg font-black text-gray-700">{sellerSettings.account_holder}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('phone_number')}</p>
                        <p className="text-lg font-black text-gray-700">{sellerSettings.phone_number}</p>
                      </div>
                    </div>
                    <p className="mt-6 text-xs text-gray-500 font-bold italic leading-relaxed">
                      {t('payment_note')}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">{t('full_name')}</label>
                      <input required type="text" value={specName} onChange={e => setSpecName(e.target.value)} placeholder="مثال: محمد علي" className="w-full px-8 py-5 bg-white border-2 border-transparent focus:border-pastel-orange rounded-3xl font-black text-gray-700 outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">{t('phone')}</label>
                      <input required type="tel" value={specPhone} onChange={e => setSpecPhone(e.target.value)} placeholder="9xxxxxxxx" className="w-full px-8 py-5 bg-white border-2 border-transparent focus:border-pastel-orange rounded-3xl font-black text-gray-700 outline-none transition-all" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">{t('specifications')}</label>
                    <textarea required value={specDesc} onChange={e => setSpecDesc(e.target.value)} placeholder={t('specifications_hint')} className="w-full px-8 py-6 bg-white border-2 border-transparent focus:border-pastel-orange rounded-[2.5rem] font-black text-gray-700 outline-none transition-all h-52 leading-relaxed"></textarea>
                  </div>

                  <div className="space-y-4">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest mr-2">{t('upload_receipt')}</label>
                    <div 
                      onClick={() => specReceiptInputRef.current?.click()}
                      className={`group relative overflow-hidden p-10 border-4 border-dashed rounded-[3rem] text-center cursor-pointer transition-all duration-500 ${
                        specReceiptImage ? 'bg-green-50 border-green-200 shadow-inner' : 'bg-white border-beige-200 hover:border-pastel-orange hover:bg-white hover:shadow-2xl'
                      }`}
                    >
                      <input 
                        ref={specReceiptInputRef}
                        type="file" 
                        accept="image/*" 
                        className="hidden" 
                        onChange={handleSpecReceiptChange} 
                      />
                      <div className="relative z-10">
                        {specReceiptImage ? (
                          <div className="flex flex-col items-center gap-3 animate-in zoom-in duration-300">
                            <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center text-2xl shadow-lg">✓</div>
                            <span className="text-green-700 font-black text-lg">{t('receipt_uploaded')}</span>
                            <button type="button" onClick={(e) => { e.stopPropagation(); setSpecReceiptImage(null); }} className="text-xs font-bold text-green-600 underline hover:text-green-800">{t('change_image')}</button>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-4">
                            <div className="w-20 h-20 bg-white rounded-3xl shadow-sm flex items-center justify-center text-4xl group-hover:scale-110 transition-transform duration-500">📸</div>
                            <div className="space-y-1">
                              <p className="text-xl font-black text-gray-800">{t('upload_receipt_hint')}</p>
                              <p className="text-gray-400 font-bold text-sm">{t('upload_receipt_formats')}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-pastel-orange text-white rounded-[2rem] font-black text-2xl shadow-2xl hover:bg-pastel-orange/90 transition-all transform active:scale-95 disabled:bg-gray-200">
                    {isSubmitting ? t('uploading') : t('send_special_request')}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {view === 'tracking' && (
        <div className="max-w-2xl mx-auto">
          <div className="bg-beige-50 rounded-[2.5rem] shadow-xl p-10 border border-beige-200">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-3xl font-black text-gray-800">{t('track_purchases')}</h2>
                <button 
                  onClick={fetchMyData} 
                  className="p-2 bg-white rounded-xl hover:bg-beige-100 transition active:scale-90"
                  title={t('refresh_data')}
                >
                  🔄
                </button>
              </div>
              <input type="tel" value={trackingPhone} onChange={e => setTrackingPhone(e.target.value)} placeholder="9xxxxxxxx" className="w-full px-8 py-5 bg-white border-2 border-transparent focus:border-pastel-orange rounded-2xl font-black text-2xl text-gray-700 outline-none mb-10" />
              <div className="space-y-4">
                {myOrders.length === 0 && mySpecials.length === 0 && trackingPhone && (
                  <p className="text-center text-gray-400 font-bold py-10">{t('no_orders_found')}</p>
                )}
                
                {myOrders.map(order => (
                  <div key={order.id} className="border-2 border-beige-100 bg-white rounded-2xl p-6 flex items-center justify-between gap-4">
                    <div className="text-gray-800">
                      <h4 className="font-black">{order.product_name}</h4>
                      <span className={`text-[10px] font-black px-3 py-1 rounded-full ${order.status === 'approved' ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'}`}>
                        {order.status === 'approved' ? t('approved') : (isEligibleForDownload(order) ? t('auto_activation') : t('pending_review'))}
                      </span>
                    </div>
                    {isEligibleForDownload(order) && (
                      <button 
                        disabled={downloadingId === order.id}
                        onClick={() => {
                          const downloadUrl = getOrderDownloadUrl(order);
                          const product = products.find(p => p.id === order.product_id);
                          
                          if (!downloadUrl) {
                            console.error("Download URL missing for order:", order.id, "Product:", product?.id);
                            if (!product) {
                              alert(`⚠️ ${t('product_not_found_error')}`);
                            } else {
                              alert(`⚠️ ${t('invalid_download_link_error')}`);
                            }
                            return;
                          }
                          
                          handleDownload(downloadUrl, `order_${order.id}_${product?.name || 'file'}`, order.id);
                        }} 
                        className="bg-pastel-orange text-white px-6 py-3 rounded-xl text-xs font-black shadow-lg disabled:bg-gray-400 hover:scale-105 transition active:scale-95"
                      >
                        {downloadingId === order.id ? t('downloading') : t('download')}
                      </button>
                    )}
                  </div>
                ))}

                {mySpecials.map(spec => (
                  <div key={spec.id} className="border-2 border-beige-100 bg-beige-50/30 rounded-2xl p-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-gray-800">
                        <h4 className="font-black">{t('special_request_id')}: {spec.id}</h4>
                        <span className={`text-[10px] font-black px-3 py-1 rounded-full ${
                          spec.status === 'delivered' ? 'bg-green-50 text-green-700' : 
                          spec.status === 'processing' ? 'bg-blue-50 text-blue-700' : 
                          spec.status === 'pending_payment' ? 'bg-amber-50 text-amber-700' : 'bg-red-50 text-red-700'
                        }`}>
                          {spec.status === 'delivered' ? t('delivered') : 
                           spec.status === 'processing' ? t('processing') : 
                           spec.status === 'pending_payment' ? t('pending_payment') : t('rejected')}
                        </span>
                      </div>
                      {spec.delivery_file_url && (
                        <button 
                          disabled={downloadingId === spec.id}
                          onClick={() => handleDownload(spec.delivery_file_url, `special_request_${spec.id}`, spec.id)} 
                          className="bg-pastel-orange text-white px-6 py-3 rounded-xl text-xs font-black shadow-lg disabled:opacity-50"
                        >
                          {downloadingId === spec.id ? t('downloading') : t('download_file')}
                        </button>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 font-bold line-clamp-1">{spec.specifications}</p>
                  </div>
                ))}
              </div>
          </div>
        </div>
      )}

      {/* باقي الـ Modals والتفاصيل كما هي مع الحفاظ على text-black */}
      {detailProduct && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-2 md:p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-beige-50 rounded-3xl md:rounded-[3rem] w-full max-w-5xl my-auto overflow-hidden flex flex-col md:flex-row text-gray-800 shadow-2xl">
            <div className="w-full md:w-1/2 bg-beige-100 flex flex-col">
              <div className="flex-grow relative aspect-square md:aspect-auto min-h-[300px] md:min-h-[500px]">
                <img 
                  src={[detailProduct.thumbnail, ...(detailProduct.images || [])][activeImageIndex]} 
                  className="w-full h-full object-cover transition-all duration-500" 
                />
              </div>
              {detailProduct.images && detailProduct.images.length > 0 && (
                <div className="p-4 bg-white/50 backdrop-blur-sm flex gap-2 overflow-x-auto scrollbar-hide">
                  {[detailProduct.thumbnail, ...detailProduct.images].map((img, idx) => (
                    <button 
                      key={idx} 
                      onClick={() => setActiveImageIndex(idx)}
                      className={`flex-shrink-0 w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden border-2 transition-all duration-300 ${activeImageIndex === idx ? 'border-pastel-orange scale-105 shadow-lg' : 'border-transparent opacity-50 hover:opacity-100'}`}
                    >
                      <img src={img} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="w-full md:w-1/2 p-6 md:p-10 flex flex-col">
               <div className="flex-grow">
                 <h2 className="text-2xl md:text-4xl font-black mb-2 md:mb-4">{detailProduct.name}</h2>
                 <div className="text-2xl md:text-3xl font-black text-pastel-orange mb-4 md:mb-6">{detailProduct.price} د.ل</div>
                 <p className="text-gray-500 font-bold text-sm md:text-base mb-6 md:mb-10 leading-relaxed">{detailProduct.description}</p>
               </div>
               <div className="space-y-3">
                 {detailProduct.preview_file_url && (
                   <button 
                     disabled={downloadingId === `preview_${detailProduct.id}`}
                     onClick={() => handleDownload(detailProduct.preview_file_url, `preview_${detailProduct.name}`, `preview_${detailProduct.id}`)} 
                     className="w-full py-3 bg-white text-gray-700 rounded-xl md:rounded-2xl font-black text-sm hover:bg-beige-100 transition disabled:opacity-50 border border-beige-100"
                   >
                     {downloadingId === `preview_${detailProduct.id}` ? t('downloading') : t('free_sample')}
                   </button>
                 )}
                 <button onClick={() => { setSelectedProduct(detailProduct); setShowCheckout(true); setDetailProduct(null); }} className="w-full py-4 md:py-6 bg-pastel-orange text-white rounded-xl md:rounded-2xl font-black text-lg md:text-2xl hover:bg-pastel-orange/90 transition shadow-xl">{t('buy_now')} 🚀</button>
                 <button onClick={() => setDetailProduct(null)} className="w-full py-2 text-gray-400 font-bold text-sm">{t('close')}</button>
               </div>
            </div>
          </div>
        </div>
      )}

      {showCheckout && selectedProduct && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-2 md:p-4 bg-black/80 backdrop-blur-sm text-gray-800 overflow-y-auto">
          <div className="bg-beige-50 rounded-3xl md:rounded-[3rem] w-full max-w-2xl p-6 md:p-10 my-auto shadow-2xl border border-beige-200">
              <h2 className="text-2xl md:text-3xl font-black mb-6 md:mb-10 text-center">{t('checkout_title')}</h2>
              <div className="space-y-4 md:space-y-6">
                <div className="bg-white p-4 md:p-6 rounded-2xl md:rounded-3xl space-y-2 border-2 border-dashed border-beige-200 text-sm md:text-base">
                   <div className="font-bold text-gray-600">{t('bank_name')}: <span className="font-black text-gray-800">{sellerSettings.bank_name}</span></div>
                   <div className="font-bold text-gray-600">{t('account_number')}: <span className="font-black text-lg md:text-xl text-gray-800">{sellerSettings.account_number}</span></div>
                   {sellerSettings.iban && (
                     <div className="font-bold text-gray-600">{t('iban')}: <span className="font-black text-gray-800">{sellerSettings.iban}</span></div>
                   )}
                   <div className="font-bold text-gray-600">{t('account_holder')}: <span className="font-black text-gray-800">{sellerSettings.account_holder}</span></div>
                   {sellerSettings.phone_number && (
                     <div className="font-bold text-gray-600">{t('phone_number')}: <span className="font-black text-gray-800">{sellerSettings.phone_number}</span></div>
                   )}
                </div>
                <input required type="text" value={buyerName} onChange={e => setBuyerName(e.target.value)} placeholder={t('full_name')} className="w-full px-5 py-3 md:px-6 md:py-4 bg-white border-2 border-transparent focus:border-pastel-orange rounded-xl md:rounded-2xl font-black outline-none text-sm md:text-base text-gray-700" />
                <input required type="tel" value={buyerPhone} onChange={e => setBuyerPhone(e.target.value)} placeholder={t('phone')} className="w-full px-5 py-3 md:px-6 md:py-4 bg-white border-2 border-transparent focus:border-pastel-orange rounded-xl md:rounded-2xl font-black outline-none text-sm md:text-base text-gray-700" />
                <div onClick={() => fileInputRef.current?.click()} className={`p-4 md:p-6 border-2 border-dashed rounded-xl md:rounded-2xl text-center cursor-pointer transition-colors ${receiptImage ? 'bg-green-50 border-green-200' : 'bg-white border-beige-200 hover:border-pastel-orange'}`}>
                  <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                  {receiptImage ? <span className="text-green-600 font-black text-sm md:text-base">✅ {t('receipt_uploaded')}</span> : <span className="font-black opacity-40 text-sm md:text-base text-gray-500">{isSubmitting ? t('uploading') : t('upload_receipt')}</span>}
                </div>
                <button disabled={isSubmitting || !receiptImage} onClick={handleSubmitOrder} className="w-full py-4 md:py-5 bg-pastel-orange text-white rounded-xl md:rounded-2xl font-black text-lg md:text-xl shadow-xl disabled:bg-gray-200 active:scale-95 transition-all">{t('send_order')}</button>
                <button onClick={() => setShowCheckout(false)} className="w-full py-2 text-gray-400 font-bold text-sm">{t('cancel')}</button>
              </div>
          </div>
        </div>
      )}
    </div>
  );
};
