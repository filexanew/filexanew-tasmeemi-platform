
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { t, i18n } = useTranslation();
  const location = useLocation();
  const isSeller = location.pathname.startsWith('/seller');

  const toggleLanguage = () => {
    const newLang = i18n.language === 'ar' ? 'en' : 'ar';
    i18n.changeLanguage(newLang);
  };

  return (
    <div className="min-h-screen flex flex-col bg-beige-50">
      <nav className="bg-white/80 backdrop-blur-md shadow-sm border-b border-beige-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-4">
              <Link to="/" className="text-2xl font-black text-gray-700 flex items-center gap-2">
                <span className="text-3xl text-pastel-orange">📐</span>
                {t('app_name')}
              </Link>
              
              <button 
                onClick={toggleLanguage}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-beige-100 text-gray-600 hover:bg-beige-200 transition-colors text-xs font-bold"
              >
                <Globe size={14} />
                {i18n.language === 'ar' ? 'English' : 'العربية'}
              </button>
            </div>
            
            <div className="flex items-center gap-2 md:gap-4">
              <Link 
                to="/" 
                className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${!isSeller ? 'bg-pastel-orange text-white shadow-lg shadow-orange-100' : 'text-gray-500 hover:bg-beige-100'}`}
              >
                {t('buyer_gallery')}
              </Link>
              <Link 
                to="/seller" 
                className={`px-4 py-2 rounded-xl text-xs md:text-sm font-bold transition-all ${isSeller ? 'bg-pastel-orange text-white shadow-lg shadow-orange-100' : 'text-gray-500 hover:bg-beige-100'}`}
              >
                {t('seller_dashboard')}
              </Link>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      <footer className="bg-white border-t border-beige-200 py-10">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="text-pastel-orange font-black text-xl mb-4">{t('app_name')}</div>
          <p className="text-gray-500 text-sm font-medium">© {new Date().getFullYear()} {t('copyright', { name: t('app_name') })}</p>
          <div className="mt-4 flex justify-center gap-4 text-xs text-gray-400">
             <span>{t('footer_text')}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
