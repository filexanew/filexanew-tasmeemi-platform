
import React, { useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Session } from '@supabase/supabase-js';
import { useTranslation } from 'react-i18next';
import { Product, Order, SellerSettings, SpecialRequest } from '../types.ts';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '../App.tsx';
import { withRetry } from '../src/utils/supabaseRetry.ts';
import { exportProjectAsZip, triggerDownload } from '../src/utils/exportProject.ts';

interface SellerDashboardProps {
  products: Product[];
  orders: Order[];
  specialRequests: SpecialRequest[];
  settings: SellerSettings;
  session: Session;
  onAddProduct: (product: Partial<Product>) => Promise<boolean>;
  onDeleteProduct: (id: string) => void;
  onUpdateOrder: (id: string, status: 'approved' | 'rejected') => void;
  onUpdateSettings: (settings: SellerSettings) => void;
  onUpdateSpecialRequest: (id: string, updates: Partial<SpecialRequest>) => void;
  onRefresh: () => void;
}

export const SellerDashboard: React.FC<SellerDashboardProps> = ({
  products,
  orders,
  specialRequests,
  settings,
  session,
  onAddProduct,
  onDeleteProduct,
  onUpdateOrder,
  onUpdateSettings,
  onUpdateSpecialRequest,
  onRefresh
}) => {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'orders' | 'products' | 'specials' | 'settings'>('orders');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isUploading, setIsUploading] = useState<string | null>(null);
  
  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCat, setNewCat] = useState('ملف ZIP 📦');
  const [newThumb, setNewThumb] = useState<string | null>(null);
  const [newPreviewFile, setNewPreviewFile] = useState<string | null>(null);
  const [newSaleFile, setNewSaleFile] = useState<string | null>(null);
  const [newExternalLink, setNewExternalLink] = useState('');
  const [newImages, setNewImages] = useState<string[]>([]);

  const [repairOrderId, setRepairOrderId] = useState<string | null>(null);
  const [repairUrl, setRepairUrl] = useState('');
  
  const [localSettings, setLocalSettings] = useState<SellerSettings>(settings);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<number | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  
  React.useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleExportProject = async () => {
    setIsExporting(true);
    setExportProgress(10);
    setExportError(null);
    try {
      const blob = await exportProjectAsZip((progress) => {
        setExportProgress(progress);
      });
      triggerDownload(blob, 'tasmeemi-digital-marketplace.zip');
    } catch (err: any) {
      console.error("Export error:", err);
      setExportError(err.message || "حدث خطأ أثناء تصدير الملفات.");
    } finally {
      setTimeout(() => {
        setIsExporting(false);
        setExportProgress(null);
      }, 1000);
    }
  };

  const thumbInputRef = useRef<HTMLInputElement>(null);
  const saleFileInputRef = useRef<HTMLInputElement>(null);
  const imagesInputRef = useRef<HTMLInputElement>(null);
  const specFileInputRef = useRef<HTMLInputElement>(null);
  const [activeSpecId, setActiveSpecId] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error("Error signing out:", error);
    }
    navigate('/login');
  };

  const stats = useMemo(() => {
    const totalSales = orders
      .filter(o => o.status === 'approved')
      .reduce((sum, o) => sum + o.price, 0);
    
    return {
      totalSales,
      pendingOrders: orders.filter(o => o.status === 'pending').length,
      pendingSpecials: specialRequests.filter(r => r.status === 'pending').length,
      activeProducts: products.length
    };
  }, [orders, specialRequests, products]);

  const uploadToSupabase = async (file: File, bucket: string): Promise<string | null> => {
    const uploadFn = async () => {
      const cleanName = file.name.replace(/[^\w.-]/g, '_');
      const fileName = `${Date.now()}_${cleanName}`;
      const uploadUrl = `${SUPABASE_URL}/storage/v1/object/${bucket}/${fileName}`;
      
      const response = await fetch(uploadUrl, {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': file.type || 'application/octet-stream'
        },
        body: file
      }).catch(err => {
        throw new Error("Failed to fetch");
      });

      if (!response.ok) {
        const responseData = await response.json();
        return { data: null, error: new Error(responseData.message || "فشل رفع الملف") };
      }

      const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(fileName);
      return { data: publicUrl, error: null };
    };

    try {
      const { data: publicUrl, error: uploadError } = await withRetry(uploadFn);
      if (uploadError) throw uploadError;
      return publicUrl;
    } catch (err: any) {
      console.error("Upload error:", err);
      const msg = err.message === 'Failed to fetch' 
        ? "فشل الاتصال بالخادم أثناء الرفع. يرجى التحقق من الإنترنت أو تعطيل مانع الإعلانات."
        : err.message;
      alert(`❌ خطأ في الرفع: ${msg}`);
      return null;
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>, type: 'thumb' | 'sale' | 'spec') => {
    const file = e.target.files?.[0];
    if (file) {
      if (type === 'spec' && activeSpecId) {
        setIsUploading(activeSpecId);
        const url = await uploadToSupabase(file, 'deliveries');
        if (url) {
          onUpdateSpecialRequest(activeSpecId, { delivery_file_url: url, status: 'delivered' });
          alert('تم رفع الملف وإكمال الطلب بنجاح!');
        }
        setIsUploading(null);
        setActiveSpecId(null);
        return;
      }

      setIsUploading(type);
      const bucket = type === 'thumb' ? 'thumbnails' : 'assets';
      const url = await uploadToSupabase(file, bucket);
      if (url) {
        if (type === 'thumb') setNewThumb(url);
        else setNewSaleFile(url);
      }
      setIsUploading(null);
    }
  };

  const handleMultipleImagesSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      setIsUploading('images');
      const uploadedUrls: string[] = [...newImages];
      for (let i = 0; i < files.length; i++) {
        const url = await uploadToSupabase(files[i], 'thumbnails');
        if (url) uploadedUrls.push(url);
      }
      setNewImages(uploadedUrls);
      setIsUploading(null);
    }
  };

  const removeImage = (index: number) => {
    setNewImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newThumb) { alert('يجب إضافة صورة عرض'); return; }
    if (!newSaleFile && !newExternalLink) { alert('يجب إضافة ملف للبيع'); return; }

    const productData: Partial<Product> = {
      id: editingProduct ? editingProduct.id : Math.random().toString(36).substring(2, 9).toUpperCase(),
      name: newName,
      price: parseFloat(newPrice),
      description: newDesc,
      category: newCat,
      thumbnail: newThumb,
      preview_file_url: newPreviewFile || undefined,
      sale_file_url: newSaleFile || newExternalLink,
      external_link: newExternalLink || undefined,
      images: newImages,
    };

    if (editingProduct) {
      // Update existing product
      const { error } = await withRetry(async () => await supabase.from('products').update(productData).eq('id', editingProduct.id));
      if (error) {
        alert(`❌ فشل التحديث: ${error.message === 'Failed to fetch' ? "فشل الاتصال بالخادم." : error.message}`);
      } else {
        alert('✅ تم تحديث المنتج بنجاح');
        onRefresh();
        setShowAddModal(false);
        setEditingProduct(null);
        resetForm();
      }
    } else {
      const successResult = await onAddProduct(productData);
      if (successResult) {
        alert('✅ تم إضافة المنتج بنجاح');
        setShowAddModal(false);
        setEditingProduct(null);
        resetForm();
      }
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setNewName(product.name);
    setNewPrice(product.price.toString());
    setNewDesc(product.description);
    setNewCat(product.category);
    setNewThumb(product.thumbnail);
    setNewPreviewFile(product.preview_file_url || null);
    setNewSaleFile(product.sale_file_url.startsWith('http') && !product.sale_file_url.includes(SUPABASE_URL) ? null : product.sale_file_url);
    setNewExternalLink(product.external_link || (product.sale_file_url.startsWith('http') && !product.sale_file_url.includes(SUPABASE_URL) ? product.sale_file_url : ''));
    setNewImages(product.images || []);
    setShowAddModal(true);
  };

  const handleRepairOrder = async () => {
    if (!repairOrderId || !repairUrl) return;
    const { error } = await withRetry(async () => await supabase.from('orders').update({ sale_file_url: repairUrl }).eq('id', repairOrderId));
    if (error) alert(`❌ فشل الإصلاح: ${error.message === 'Failed to fetch' ? "فشل الاتصال بالخادم." : error.message}`);
    else {
      alert('✅ تم إصلاح رابط الطلب بنجاح');
      setRepairOrderId(null);
      setRepairUrl('');
      onRefresh();
    }
  };

  const handleAutoSyncAll = async () => {
    const missingLinks = orders.filter(o => o.status === 'approved' && (!o.sale_file_url || o.sale_file_url.trim() === ''));
    if (missingLinks.length === 0) {
      alert('✅ لا توجد طلبات تحتاج لإصلاح حالياً.');
      return;
    }

    let fixedCount = 0;
    for (const order of missingLinks) {
      const product = products.find(p => p.id === order.product_id);
      if (product && product.sale_file_url) {
        const { error } = await withRetry(async () => await supabase.from('orders').update({ sale_file_url: product.sale_file_url }).eq('id', order.id));
        if (!error) fixedCount++;
      }
    }

    if (fixedCount > 0) {
      alert(`✅ تم إصلاح ${fixedCount} طلبات تلقائياً من روابط المنتجات!`);
      onRefresh();
    } else {
      alert('⚠️ لم يتم العثور على روابط للمنتجات المرتبطة بهذه الطلبات. يرجى إصلاحها يدوياً.');
    }
  };

  const resetForm = () => {
    setNewName(''); setNewPrice(''); setNewDesc(''); setNewThumb(null); 
    setNewPreviewFile(null); setNewSaleFile(null); setNewExternalLink('');
    setNewImages([]);
  };

  const handleDownload = async (url: string | undefined, fileName: string, id: string) => {
    if (!url) return;
    setDownloadingId(id);
    try {
      if (url.includes(SUPABASE_URL) && url.includes('/storage/v1/object/public/')) {
        const parts = url.split('/storage/v1/object/public/');
        if (parts.length > 1) {
          const pathParts = parts[1].split('/');
          const bucket = pathParts[0];
          const path = pathParts.slice(1).join('/');
          const { data, error } = await withRetry(async () => await supabase.storage.from(bucket).download(path));
          if (error) throw error;
          if (data) {
            const blobUrl = window.URL.createObjectURL(data);
            const link = document.body.appendChild(document.createElement('a'));
            link.href = blobUrl;
            const extension = path.split('.').pop() || '';
            const finalFileName = extension && !fileName.includes('.') ? `${fileName}.${extension}` : fileName;
            link.download = finalFileName;
            link.click();
            setTimeout(() => { link.remove(); window.URL.revokeObjectURL(blobUrl); }, 100);
            return;
          }
        }
      }
      // الملاذ الأخير: فتح الرابط في نافذة جديدة لتجنب مشاكل CORS
      window.open(url, '_blank');
    } catch (error) {
      console.error("Download error:", error);
      window.open(url, '_blank');
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-3xl font-black text-gray-800">{t('seller_dashboard')} 👋</h1>
          <p className="text-gray-500 font-bold italic">{t('footer_text')}</p>
        </div>
        <button 
          onClick={handleLogout} 
          className="bg-pastel-orange text-white px-6 py-3 rounded-2xl text-sm font-black hover:bg-pastel-orange/90 transition shadow-lg active:scale-95"
        >
          {t('logout')} 🚪
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-pastel-orange p-6 rounded-3xl text-white shadow-lg"><p className="text-xs font-bold opacity-80 mb-1">{t('stats_sales')}</p><p className="text-3xl font-black">{stats.totalSales} د.ل</p></div>
        <div className="bg-beige-50 p-6 rounded-3xl border-2 border-beige-200"><p className="text-xs font-bold text-gray-400 mb-1">{t('stats_pending')}</p><p className="text-3xl font-black text-gray-800">{stats.pendingOrders}</p></div>
        <div className="bg-beige-50 p-6 rounded-3xl border-2 border-beige-200"><p className="text-xs font-bold text-gray-400 mb-1">{t('stats_specials')}</p><p className="text-3xl font-black text-gray-800">{stats.pendingSpecials}</p></div>
        <div className="bg-beige-50 p-6 rounded-3xl border-2 border-beige-200"><p className="text-xs font-bold text-gray-400 mb-1">{t('stats_products')}</p><p className="text-3xl font-black text-gray-800">{stats.activeProducts}</p></div>
      </div>

      {products.filter(p => !p.sale_file_url || p.sale_file_url.trim() === '').length > 0 && (
        <div className="bg-red-50 border-2 border-red-200 p-6 rounded-3xl mb-8 flex flex-col md:flex-row items-center justify-between gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex items-center gap-4">
            <div className="text-3xl">⚠️</div>
            <div>
              <h3 className="text-red-700 font-black text-lg">تنبيه: روابط تحميل مفقودة!</h3>
              <p className="text-red-600 text-xs font-bold mb-2">الأعمال التالية تفتقد لروابط التحميل، لن يتمكن المشترون من الحصول عليها:</p>
              <div className="flex flex-wrap gap-2">
                {products.filter(p => !p.sale_file_url || p.sale_file_url.trim() === '').map(p => (
                  <span key={p.id} className="bg-red-100 text-red-700 px-2 py-1 rounded-lg text-[10px] font-black border border-red-200">
                    {p.name} (#{p.id})
                  </span>
                ))}
              </div>
            </div>
          </div>
          <button onClick={() => setActiveTab('products')} className="bg-red-600 text-white px-8 py-4 rounded-2xl text-sm font-black shadow-xl hover:bg-red-700 transition-all active:scale-95 whitespace-nowrap">إصلاح الآن 🛠️</button>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-64 space-y-3">
          <button onClick={() => setActiveTab('orders')} className={`w-full text-right px-6 py-4 rounded-2xl font-black transition-all ${activeTab === 'orders' ? 'bg-pastel-orange text-white shadow-md' : 'bg-beige-50 text-gray-500 border border-beige-200 hover:bg-beige-100'}`}>{t('tab_orders')}</button>
          <button onClick={() => setActiveTab('specials')} className={`w-full text-right px-6 py-4 rounded-2xl font-black transition-all ${activeTab === 'specials' ? 'bg-pastel-orange text-white shadow-md' : 'bg-beige-50 text-gray-500 border border-beige-200 hover:bg-beige-100'}`}>{t('tab_specials')}</button>
          <button onClick={() => setActiveTab('products')} className={`w-full text-right px-6 py-4 rounded-2xl font-black transition-all ${activeTab === 'products' ? 'bg-pastel-orange text-white shadow-md' : 'bg-beige-50 text-gray-500 border border-beige-200 hover:bg-beige-100'}`}>{t('tab_products')}</button>
          <button onClick={() => setActiveTab('settings')} className={`w-full text-right px-6 py-4 rounded-2xl font-black transition-all ${activeTab === 'settings' ? 'bg-pastel-orange text-white shadow-md' : 'bg-beige-50 text-gray-500 border border-beige-200 hover:bg-beige-100'}`}>{t('tab_settings')}</button>
        </div>

        <div className="flex-grow bg-beige-50/50 rounded-[2rem] border-2 border-beige-200 p-8 min-h-[500px]">
          {activeTab === 'orders' && (
            <div className="space-y-6">
               <div className="flex justify-between items-center mb-6">
                 <h2 className="text-2xl font-black text-gray-800">{t('review_orders')}</h2>
                 <button 
                  onClick={handleAutoSyncAll}
                  className="text-[10px] font-black bg-beige-100 text-gray-700 px-4 py-2 rounded-xl border border-beige-200 hover:bg-beige-200 transition"
                  title={t('auto_repair_all')}
                 >
                   {t('auto_repair_all')} 🪄
                 </button>
               </div>
               {orders.length === 0 ? <p className="text-gray-400 text-center py-20 font-bold">{t('no_orders_yet')}</p> : (
                 <div className="space-y-4">
                   {orders.map(order => (
                     <div key={order.id} className="border-2 border-beige-100 bg-white rounded-2xl p-6 flex flex-col space-y-4">
                       <div className="flex flex-wrap justify-between items-center gap-4">
                         <div className="flex items-center gap-4 text-gray-800">
                            <div className="w-12 h-12 bg-beige-100 rounded-xl flex items-center justify-center text-xl text-pastel-orange">📦</div>
                            <div><div className="font-black">{order.product_name}</div><div className="text-[10px] font-bold opacity-40">ID: {order.product_id} | {order.buyer_phone}</div></div>
                         </div>
                         <div className="flex items-center gap-6">
                            <button onClick={() => window.open(order.receipt_image)} className="text-xs font-black text-pastel-orange underline">{t('view_receipt')}</button>
                            {order.status === 'pending' ? (
                              <div className="flex gap-2">
                                <button onClick={() => onUpdateOrder(order.id, 'approved')} className="bg-pastel-orange text-white px-4 py-2 rounded-xl text-xs font-black">{t('approve')} ✅</button>
                                <button onClick={() => onUpdateOrder(order.id, 'rejected')} className="bg-red-50 text-red-600 px-4 py-2 rounded-xl text-xs font-black">{t('reject')}</button>
                              </div>
                            ) : <span className={`text-xs font-black px-4 py-2 rounded-xl ${order.status === 'approved' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>{order.status === 'approved' ? t('approved') : t('rejected')}</span>}
                         </div>
                       </div>
                       
                       {/* Repair Link Section */}
                       {order.status === 'approved' && (!order.sale_file_url || order.sale_file_url.trim() === '') && (
                         <div className="bg-beige-50 p-4 rounded-xl border border-beige-100 flex flex-col md:flex-row items-center gap-3">
                           <p className="text-[10px] font-black text-red-600 flex-grow">⚠️ رابط التحميل مفقود لهذا الطلب! يرجى إصلاحه لكي يتمكن المشتري من التحميل.</p>
                           
                           {repairOrderId === order.id ? (
                             <div className="flex gap-2 w-full md:w-auto">
                               <input 
                                 type="text" 
                                 placeholder="ضع رابط الملف هنا..." 
                                 value={repairUrl}
                                 onChange={e => setRepairUrl(e.target.value)}
                                 className="flex-grow px-3 py-2 bg-white border border-red-200 rounded-lg text-xs outline-none"
                               />
                               <button onClick={handleRepairOrder} className="bg-red-600 text-white px-4 py-2 rounded-lg text-xs font-black">حفظ</button>
                               <button onClick={() => setRepairOrderId(null)} className="text-gray-400">✖</button>
                             </div>
                           ) : (
                             <div className="flex gap-2">
                               {products.find(p => p.id === order.product_id)?.sale_file_url && (
                                 <button 
                                   onClick={() => {
                                     const prodLink = products.find(p => p.id === order.product_id)?.sale_file_url;
                                     if (prodLink) {
                                       setRepairUrl(prodLink);
                                       setRepairOrderId(order.id);
                                     }
                                   }}
                                   className="bg-pastel-orange text-white px-4 py-2 rounded-xl text-xs font-black shadow-sm"
                                 >
                                   مزامنة من المنتج 🔄
                                 </button>
                               )}
                               <button onClick={() => setRepairOrderId(order.id)} className="bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-black shadow-sm">إصلاح يدوي 🛠️</button>
                             </div>
                           )}
                         </div>
                       )}
                     </div>
                   ))}
                 </div>
               )}
            </div>
          )}

          {activeTab === 'specials' && (
            <div className="space-y-6">
               <h2 className="text-2xl font-black text-gray-800 mb-6">{t('special_requests_title')}</h2>
               {specialRequests.length === 0 ? <p className="text-gray-400 text-center py-20 font-bold">{t('no_special_requests_yet')}</p> : (
                 <div className="space-y-4">
                   {specialRequests.map(req => (
                     <div key={req.id} className="border-2 border-beige-100 bg-white rounded-3xl p-8 space-y-4">
                        <div className="flex justify-between items-start">
                           <div>
                              <h3 className="text-xl font-black text-gray-800">{req.buyer_name}</h3>
                              <p className="text-pastel-orange font-bold">{req.buyer_phone}</p>
                           </div>
                           <span className={`px-4 py-2 rounded-xl text-xs font-black ${
                             req.status === 'pending_payment' ? 'bg-amber-50 text-amber-700' : 
                             req.status === 'processing' ? 'bg-blue-50 text-blue-700' : 
                             req.status === 'delivered' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                           }`}>
                             {req.status === 'pending_payment' ? t('pending_payment') : 
                              req.status === 'processing' ? t('processing') : 
                              req.status === 'delivered' ? t('delivered') : t('rejected')}
                           </span>
                        </div>
                        <div className="bg-beige-50 p-6 rounded-2xl border border-beige-100">
                           <p className="text-gray-600 font-bold leading-relaxed whitespace-pre-wrap">{req.specifications}</p>
                           {req.receipt_image && (
                             <div className="mt-4">
                               <p className="text-xs text-gray-400 mb-2">{t('view_receipt')}:</p>
                               <img 
                                 src={req.receipt_image} 
                                 alt="Receipt" 
                                 className="w-32 h-32 object-cover rounded-xl cursor-pointer hover:opacity-80 transition"
                                 onClick={() => window.open(req.receipt_image, '_blank')}
                                 referrerPolicy="no-referrer"
                               />
                             </div>
                           )}
                        </div>
                        <div className="flex gap-3">
                           {req.status === 'pending_payment' && (
                             <>
                               <button onClick={() => onUpdateSpecialRequest(req.id, { status: 'processing' })} className="bg-pastel-orange text-white px-6 py-3 rounded-xl text-xs font-black">{t('approve')} 🚀</button>
                               <button onClick={() => onUpdateSpecialRequest(req.id, { status: 'rejected' })} className="bg-red-50 text-red-600 px-6 py-3 rounded-xl text-xs font-black">{t('reject')} ✖️</button>
                             </>
                           )}
                           {req.status === 'processing' && (
                             <div className="flex gap-2">
                               <input ref={specFileInputRef} type="file" className="hidden" onChange={e => handleFileSelect(e, 'spec')} />
                               <button 
                                 onClick={() => { setActiveSpecId(req.id); specFileInputRef.current?.click(); }} 
                                 disabled={isUploading === req.id}
                                 className="bg-pastel-orange text-white px-6 py-3 rounded-xl text-xs font-black shadow-lg hover:bg-pastel-orange/90 transition"
                               >
                                 {isUploading === req.id ? t('uploading') : t('upload_final')}
                               </button>
                             </div>
                           )}
                           {req.status === 'delivered' && req.delivery_file_url && (
                             <button 
                               disabled={downloadingId === req.id}
                               onClick={() => handleDownload(req.delivery_file_url, `delivery_${req.id}`, req.id)} 
                               className="bg-beige-50 text-gray-800 px-6 py-3 rounded-xl text-xs font-black disabled:opacity-50 border border-beige-100"
                             >
                               {downloadingId === req.id ? t('downloading') : t('view_uploaded')}
                             </button>
                           )}
                           <button onClick={() => window.open(`https://wa.me/${req.buyer_phone.replace(/^0/, '218')}`, '_blank')} className="bg-green-50 text-green-600 px-6 py-3 rounded-xl text-xs font-black">{t('contact_whatsapp')} 💬</button>
                        </div>
                     </div>
                   ))}
                 </div>
               )}
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black text-gray-800">{t('my_gallery')}</h2>
                <button onClick={() => setShowAddModal(true)} className="bg-pastel-orange text-white px-6 py-3 rounded-xl font-black transition hover:scale-105 active:scale-95 shadow-lg">+ {t('add_new_work')}</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map(p => (
                  <div key={p.id} className="border-2 border-beige-100 rounded-2xl overflow-hidden group relative bg-beige-50">
                    <img src={p.thumbnail} className="aspect-video w-full object-cover group-hover:scale-105 transition" />
                    <div className="p-4 flex justify-between items-center">
                      <div className="text-gray-800"><div className="font-black truncate w-32">{p.name}</div><div className="text-pastel-orange font-black text-sm">{p.price} د.ل</div></div>
                      <div className="flex gap-1">
                        <button onClick={() => handleEditProduct(p)} className="text-gray-400 p-2 hover:bg-beige-100 hover:text-pastel-orange rounded-lg transition">✏️</button>
                        <button onClick={() => onDeleteProduct(p.id)} className="text-gray-400 p-2 hover:bg-red-50 hover:text-red-500 rounded-lg transition">🗑️</button>
                      </div>
                    </div>
                    {(!p.sale_file_url || p.sale_file_url.trim() === '') && (
                      <div className="absolute top-2 right-2 bg-red-600 text-white text-[8px] font-black px-2 py-1 rounded-full shadow-lg animate-pulse z-10">{t('repair_link')}!</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="max-w-xl">
               <h2 className="text-2xl font-black mb-8 text-gray-800">{t('payment_settings')}</h2>
               <div className="space-y-4">
                  <div>
                    <label className="text-xs font-black text-gray-400 block mb-1">{t('bank_name')}</label>
                    <input 
                      type="text" 
                      value={localSettings.bank_name || ''} 
                      onChange={e => setLocalSettings({...localSettings, bank_name: e.target.value})} 
                      className="w-full px-4 py-3 bg-beige-50 rounded-xl font-black text-gray-800 outline-none border-2 border-transparent focus:border-pastel-orange transition" 
                    />
                  </div>
                  <div>
                    <label className="text-xs font-black text-gray-400 block mb-1">{t('account_holder')}</label>
                    <input 
                      type="text" 
                      value={localSettings.account_holder || ''} 
                      onChange={e => setLocalSettings({...localSettings, account_holder: e.target.value})} 
                      className="w-full px-4 py-3 bg-beige-50 rounded-xl font-black text-gray-800 outline-none border-2 border-transparent focus:border-pastel-orange transition" 
                    />
                  </div>
                  <div>
                    <label className="text-xs font-black text-gray-400 block mb-1">{t('account_number')}</label>
                    <input 
                      type="text" 
                      value={localSettings.account_number || ''} 
                      onChange={e => setLocalSettings({...localSettings, account_number: e.target.value})} 
                      className="w-full px-4 py-3 bg-beige-50 rounded-xl font-black text-gray-800 text-center outline-none border-2 border-transparent focus:border-pastel-orange transition" 
                    />
                  </div>
                  <div>
                    <label className="text-xs font-black text-gray-400 block mb-1">{t('iban')}</label>
                    <input 
                      type="text" 
                      value={localSettings.iban || ''} 
                      onChange={e => setLocalSettings({...localSettings, iban: e.target.value})} 
                      className="w-full px-4 py-3 bg-beige-50 rounded-xl font-black text-gray-800 text-center outline-none border-2 border-transparent focus:border-pastel-orange transition" 
                      placeholder="LYxxxxxxxxxxxxxxxxxxxxxxxx"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-black text-gray-400 block mb-1">{t('phone_number')}</label>
                    <input 
                      type="text" 
                      value={localSettings.phone_number || ''} 
                      onChange={e => setLocalSettings({...localSettings, phone_number: e.target.value})} 
                      className="w-full px-4 py-3 bg-beige-50 rounded-xl font-black text-gray-800 text-center outline-none border-2 border-transparent focus:border-pastel-orange transition" 
                      placeholder="9xxxxxxxx"
                    />
                  </div>
                  <button 
                    onClick={() => onUpdateSettings(localSettings)} 
                    className="w-full py-4 bg-pastel-orange text-white rounded-xl font-black mt-4 shadow-xl hover:bg-pastel-orange/90 transition active:scale-95 text-center block"
                  >
                    {t('save_settings')} ✅
                  </button>
               </div>

               {/* Developer Export & ZIP packaging section */}
               <div className="mt-12 pt-8 border-t-2 border-dashed border-beige-200">
                 <h3 className="text-xl font-black mb-2 text-gray-800 flex items-center gap-2">
                   <span>💻</span> مركز المبرمجين وتصدير الكود المصدري
                 </h3>
                 <p className="text-xs font-bold text-gray-500 mb-6 leading-relaxed">
                   هل ترغب في رفع موقعك بنفسك على GitHub أو استضافته على Netlify؟ يسعدنا جداً تمكينك من ذلك! يمكنك الآن بنقرة زر واحدة تحميل كامل ملفات المشروع الحالية مرتبة وجاهزة للتشغيل والتحميل كما قمنا ببنائها لك تماماً.
                 </p>
                 
                   <div className="bg-white p-6 rounded-3xl border border-beige-200 space-y-4 mb-6">
                     <h4 className="font-black text-xs text-pastel-orange uppercase tracking-wider">💡 أهم إرشادات الاستضافة الناجحة على Netlify:</h4>
                     <ul className="text-xs text-gray-600 font-bold space-y-2 list-disc list-inside leading-loose">
                       <li>قم برفع الملف المضغوط بالكامل أو تفريغه في مستودع GitHub الخاص بك.</li>
                       <li>أثناء ضبط الإعدادات في Netlify، تأكد من وضع أمر البناء (Build Command) كـ <code className="bg-beige-100 text-pastel-orange px-1.5 py-0.5 rounded font-mono font-bold">npm run build</code>.</li>
                       <li>تأكد من وضع مجلد النشر (Publish Directory) كـ <code className="bg-beige-100 text-pastel-orange px-1.5 py-0.5 rounded font-mono font-bold">dist</code>.</li>
                       <li>لقد قمنا بتضمين ملف <code className="bg-beige-100 text-pastel-orange px-1.5 py-0.5 rounded font-mono font-bold">_redirects</code> مسبقاً داخل مجلد <code className="bg-beige-100/50 px-1.5 py-0.5 rounded">public</code> لضمان عدم ظهور صفحة بيضاء أو خطأ 404 عند تحديث مشترياتك أو لوحة التحكم.</li>
                     </ul>
                   </div>

                 {exportError && (
                   <div className="bg-red-50 text-red-600 p-4 rounded-xl text-xs font-bold border border-red-100 mb-4">
                     ⚠️ {exportError}
                   </div>
                 )}

                 {isExporting ? (
                   <div className="space-y-3 bg-beige-50/50 p-6 rounded-3xl border border-beige-200">
                     <div className="flex justify-between items-center text-xs font-black text-gray-700">
                       <span>جاري تحضير الكود وحزم الملفات...</span>
                       <span>{exportProgress}%</span>
                     </div>
                     <div className="w-full bg-beige-100 rounded-full h-3 overflow-hidden">
                       <div 
                         className="bg-pastel-orange h-3 rounded-full transition-all duration-300"
                         style={{ width: `${exportProgress}%` }}
                       ></div>
                     </div>
                   </div>
                 ) : (
                   <button 
                     type="button"
                     onClick={handleExportProject}
                     className="w-full py-5 bg-gray-900 text-white rounded-2xl font-black text-sm md:text-base hover:bg-gray-800 transition active:scale-95 shadow-xl flex items-center justify-center gap-2"
                   >
                     <span>📦</span> تحميل المشروع بالكامل كملف ZIP جاهز للرفع
                   </button>
                 )}
               </div>
            </div>
          )}
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-beige-50 rounded-[2.5rem] w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-8 md:p-12 border border-beige-200">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-black text-gray-800">{editingProduct ? t('edit_work') : t('add_new_work')}</h2>
              <button onClick={() => { setShowAddModal(false); setEditingProduct(null); resetForm(); }} className="text-gray-300 hover:text-pastel-orange transition-colors"><svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
            
            <form onSubmit={handleAddProduct} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-black text-gray-700">{t('work_title')}</label>
                  <input required type="text" value={newName} onChange={e => setNewName(e.target.value)} className="w-full px-6 py-4 bg-white border-2 border-beige-100 rounded-2xl font-black text-gray-800 outline-none focus:border-pastel-orange transition" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-black text-gray-700">{t('work_price')} (د.ل)</label>
                  <input required type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} className="w-full px-6 py-4 bg-white border-2 border-beige-100 rounded-2xl font-black text-gray-800 outline-none focus:border-pastel-orange transition" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-black text-gray-700">{t('work_description')}</label>
                <textarea required value={newDesc} onChange={e => setNewDesc(e.target.value)} className="w-full px-6 py-4 bg-white border-2 border-beige-100 rounded-2xl font-black text-gray-800 outline-none focus:border-pastel-orange transition h-32"></textarea>
              </div>

              <div className="space-y-2">
                 <label className="text-sm font-black text-gray-700">{t('work_type')}</label>
                 <select value={newCat} onChange={e => setNewCat(e.target.value)} className="w-full px-6 py-4 bg-white border-2 border-beige-100 rounded-2xl font-black text-gray-800 outline-none focus:border-pastel-orange transition appearance-none">
                    <option value="ملف PDF 📄">ملف PDF 📄</option>
                    <option value="ملف ZIP 📦">ملف ZIP 📦</option>
                    <option value="تصميم SVG 📐">تصميم SVG 📐</option>
                    <option value="ملف PSD 🎨">فوتوشوب PSD 🎨</option>
                    <option value="ملف AI 🖌️">إليستريتور AI 🖌️</option>
                    <option value="صور PNG/JPG 🖼️">صور PNG/JPG 🖼️</option>
                    <option value="فيديو MP4 🎥">فيديو MP4 🎥</option>
                 </select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div onClick={() => thumbInputRef.current?.click()} className={`p-6 border-2 border-dashed rounded-2xl text-center cursor-pointer transition ${newThumb ? 'bg-green-50 border-green-200' : 'bg-white border-beige-200'}`}>
                    <input ref={thumbInputRef} type="file" accept="image/*" className="hidden" onChange={e => handleFileSelect(e, 'thumb')} />
                    <div className="text-xs font-black text-gray-800">{isUploading === 'thumb' ? t('uploading') : (newThumb ? '✅ ' + t('receipt_uploaded') : '🖼️ ' + t('thumbnail'))}</div>
                </div>
                <div onClick={() => saleFileInputRef.current?.click()} className={`p-6 border-2 border-dashed rounded-2xl text-center cursor-pointer transition ${newSaleFile ? 'bg-pastel-orange/5 border-pastel-orange/20' : 'bg-white border-beige-200'}`}>
                    <input ref={saleFileInputRef} type="file" className="hidden" onChange={e => handleFileSelect(e, 'sale')} />
                    <div className="text-xs font-black text-gray-800">{isUploading === 'sale' ? t('uploading') : (newSaleFile ? '✅ ' + t('receipt_uploaded') : '📁 ' + t('sale_file'))}</div>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-sm font-black text-gray-700">صور إضافية للمنتج (اختياري)</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {newImages.map((img, idx) => (
                    <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border-2 border-beige-100">
                      <img src={img} className="w-full h-full object-cover" />
                      <button 
                        type="button" 
                        onClick={() => removeImage(idx)}
                        className="absolute top-1 right-1 bg-red-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs shadow-lg"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <div 
                    onClick={() => imagesInputRef.current?.click()}
                    className="aspect-square border-2 border-dashed border-beige-200 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-pastel-orange transition bg-white"
                  >
                    <input 
                      ref={imagesInputRef} 
                      type="file" 
                      accept="image/*" 
                      multiple 
                      className="hidden" 
                      onChange={handleMultipleImagesSelect} 
                    />
                    <span className="text-2xl mb-1">➕</span>
                    <span className="text-[10px] font-black text-gray-400">{isUploading === 'images' ? t('uploading') : 'أضف صور'}</span>
                  </div>
                </div>
              </div>

              <button disabled={!!isUploading} type="submit" className="w-full py-5 bg-pastel-orange text-white rounded-2xl font-black text-xl shadow-2xl hover:bg-pastel-orange/90 transition active:scale-95 disabled:bg-gray-300">
                {editingProduct ? t('save') + ' ✨' : t('publish_now') + ' 🚀'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
